"""
Shopping Agent: semantic product search using sentence-transformers + FAISS,
then the LLM phrases a natural recommendation from the top matches.
"""
import sys
import re
from pathlib import Path

import pandas as pd
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer

sys.path.append(str(Path(__file__).parent.parent))
from llm_client import chat

DATA_PATH = Path(__file__).parent.parent / "data" / "products.csv"

SYSTEM_PROMPT = """You are the Shopping Agent inside Zoar, a personal AI assistant.
You are given a user's request and a short list of matching products (name, price,
description). Recommend the best 1-3 options in a friendly, concise way (3-5 sentences).
Mention prices in rupees. If nothing in the list truly fits, say so honestly.
"""

_model = None
_index = None
_df = None


def _load():
    """Lazy-load the embedding model, product data, and FAISS index (once)."""
    global _model, _index, _df
    if _model is not None:
        return

    _df = pd.read_csv(DATA_PATH)
    _model = SentenceTransformer("all-MiniLM-L6-v2")  # small, fast, free, local

    texts = (_df["name"] + " - " + _df["category"] + " - " + _df["description"]).tolist()
    embeddings = _model.encode(texts, normalize_embeddings=True)

    dim = embeddings.shape[1]
    _index = faiss.IndexFlatIP(dim)  # cosine similarity via inner product on normalized vecs
    _index.add(np.array(embeddings, dtype="float32"))


def _extract_budget(user_message: str):
    """Very simple regex to pull a rupee budget out of the message, if present."""
    match = re.search(r"(\d{3,6})", user_message.replace(",", ""))
    return int(match.group(1)) if match else None


def search_products(query: str, top_k: int = 5):
    _load()
    query_vec = _model.encode([query], normalize_embeddings=True)
    scores, idxs = _index.search(np.array(query_vec, dtype="float32"), top_k)

    results = _df.iloc[idxs[0]].copy()
    results["score"] = scores[0]

    budget = _extract_budget(query)
    if budget:
        results = results[results["price"] <= budget]

    return results.head(3)


def handle(user_message: str) -> str:
    """Main entry point called by the Orchestrator."""
    matches = search_products(user_message)

    if matches.empty:
        return ("I couldn't find anything matching that in the current catalog "
                "(it's just a small demo dataset). Try a different search or budget.")

    product_lines = "\n".join(
        f"- {row['name']} ({row['category']}) — Rs.{row['price']} — {row['description']}"
        for _, row in matches.iterrows()
    )
    prompt = f"User request: {user_message}\n\nMatching products:\n{product_lines}"
    return chat(SYSTEM_PROMPT, prompt)


if __name__ == "__main__":
    print(handle("I need running shoes under 3000 rupees"))
