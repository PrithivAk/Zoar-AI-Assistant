"""
Interview Agent: runs a short mock interview session.
Picks a question, takes the answer, generates ONE dynamic follow-up,
then after N questions gives a feedback summary.
"""
import sys
import json
import random
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))
from llm_client import chat

QUESTIONS_PATH = Path(__file__).parent.parent / "data" / "questions.json"

FOLLOWUP_PROMPT = """You are a friendly technical/HR interviewer.
The candidate was asked: "{question}"
They answered: "{answer}"

Write ONE short, natural follow-up question based on their answer (max 25 words).
Output ONLY the follow-up question, nothing else.
"""

FEEDBACK_PROMPT = """You are an interview coach. Here is a transcript of a mock interview
(question/answer pairs):

{transcript}

Give a short, encouraging summary (4-6 sentences) covering:
1. Overall impression
2. One specific strength
3. Two concrete tips to improve
"""


def _load_questions():
    with open(QUESTIONS_PATH) as f:
        return json.load(f)


def get_random_question(category: str | None = None) -> str:
    bank = _load_questions()
    category = category if category in bank else random.choice(list(bank.keys()))
    return random.choice(bank[category])


def get_followup(question: str, answer: str) -> str:
    return chat("You generate concise interview follow-up questions.",
                FOLLOWUP_PROMPT.format(question=question, answer=answer))


def get_feedback(transcript: list[tuple[str, str]]) -> str:
    """transcript: list of (question, answer) tuples."""
    formatted = "\n".join(f"Q: {q}\nA: {a}" for q, a in transcript)
    return chat("You are a supportive interview coach.", FEEDBACK_PROMPT.format(transcript=formatted))


def handle(user_message: str) -> str:
    """
    Simple stateless entry point for the Orchestrator demo:
    just returns a fresh question. Full session logic (multi-turn,
    follow-ups, feedback) is handled in app.py using st.session_state,
    since it needs to persist across turns.
    """
    return f"Let's start a mock interview! Here's your first question:\n\n{get_random_question()}"


if __name__ == "__main__":
    q = get_random_question("technical")
    print("Q:", q)
    a = "A hash table maps keys to values using a hash function for fast lookup."
    print("Follow-up:", get_followup(q, a))
    print("Feedback:", get_feedback([(q, a)]))
