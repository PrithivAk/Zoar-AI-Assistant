"""
Wellness Agent: daily mood check-in, logs mood 1-5, shows a simple trend.
Framed as a "mood journal", not therapy.
"""
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))
from llm_client import chat
from db import log_mood, get_recent_moods

SYSTEM_PROMPT = """You are the Wellness Agent inside Zoar, a personal AI assistant.
You run brief, warm daily mood check-ins — like a mood journal, NOT therapy.
Keep replies short (2-4 sentences). Acknowledge how the user feels, then ask
one gentle follow-up if it feels natural. Do not diagnose or give medical advice.
"""

SCORE_PROMPT = """Based on this message, output ONLY a single integer from 1 to 5
representing the person's mood (1 = very low, 5 = very good). Output nothing else.

Message: {message}
"""


def _extract_mood_score(user_message: str) -> int:
    try:
        raw = chat("You output only a single digit 1-5.", SCORE_PROMPT.format(message=user_message))
        digits = "".join(ch for ch in raw if ch.isdigit())
        score = int(digits[0]) if digits else 3
        return max(1, min(5, score))
    except Exception:
        return 3  # neutral fallback


def handle(user_message: str) -> str:
    """Main entry point called by the Orchestrator."""
    score = _extract_mood_score(user_message)
    log_mood(score, note=user_message[:200])
    reply = chat(SYSTEM_PROMPT, user_message)
    return reply


def mood_trend_text(limit: int = 7) -> str:
    """Simple text summary of recent mood trend (used in Streamlit chart tab too)."""
    rows = get_recent_moods(limit)
    if not rows:
        return "No mood entries yet — check in to start your trend!"
    scores = [r["mood_score"] for r in rows]
    avg = sum(scores) / len(scores)
    low_days = sum(1 for s in scores if s <= 2)
    return f"Last {len(scores)} entries — average mood: {avg:.1f}/5, low days: {low_days}."


if __name__ == "__main__":
    print(handle("I'm feeling a bit anxious about my interview tomorrow"))
    print(mood_trend_text())
